# SatsVoucher — Cloudflare Worker

LNURL-withdraw server for the SatsVoucher POS terminal.

## Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/voucher` | `X-Worker-Secret` header | Create a voucher, returns `{ id, lnurl, expiryDate }` |
| GET | `/voucher/:id` | none | Status check for cashier |
| GET | `/lnurlw/:id` | none | LNURL-withdraw info (called by customer wallet) |
| GET | `/lnurlw/callback/:id` | none | Redemption callback (called by customer wallet) |

## Deploy

### 1. Install Wrangler

```bash
npm install -g wrangler
wrangler login
```

### 2. Create KV namespace

```bash
wrangler kv:namespace create VOUCHERS
```

Copy the `id` from the output and paste it into `wrangler.toml`:

```toml
[[kv_namespaces]]
binding = "VOUCHERS"
id = "YOUR_ID_HERE"
```

### 3. Set secrets

```bash
wrangler secret put BLINK_API_KEY
wrangler secret put BLINK_WALLET_ID
wrangler secret put WORKER_SECRET
```

`WORKER_SECRET` is a string you choose — the POS app must send it as the
`X-Worker-Secret` header on every `POST /voucher` request. Use something
long and random, e.g. output of `openssl rand -hex 32`.

### 4. Install dependencies and deploy

```bash
npm install
npm run deploy
```

Wrangler prints your worker URL, e.g.:
`https://satsvoucher-worker.YOUR-SUBDOMAIN.workers.dev`

Enter this URL in the POS app settings screen.

### Local development

```bash
npm run dev
```

This runs the worker locally at `http://localhost:8787`. Note: LNURL-withdraw
requires a publicly reachable HTTPS URL for real wallet testing. Use
`wrangler dev --remote` to test against the live KV namespace, or use
[cloudflared tunnel](https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/)
to expose localhost.

## POST /voucher — request body

```json
{
  "amountBtc": 0.00015,
  "amountFiat": 10.00,
  "currency": "GBP",
  "expiryDays": 90
}
```

Headers:
```
Content-Type: application/json
X-Worker-Secret: <your secret>
```

Response:
```json
{
  "id": "X4K-92M",
  "lnurl": "LNURL1...",
  "expiryDate": "2025-06-12T10:00:00.000Z",
  "createdAt": "2025-03-14T10:00:00.000Z"
}
```

## GET /voucher/:id — status check response

```json
{
  "id": "X4K-92M",
  "status": "active",
  "amountBtc": 0.00015,
  "amountFiat": 10.00,
  "currency": "GBP",
  "createdAt": "2025-03-14T10:00:00.000Z",
  "expiryDate": "2025-06-12T10:00:00.000Z",
  "claimedAt": null
}
```

`status` is one of: `active` · `claimed` · `expired`
