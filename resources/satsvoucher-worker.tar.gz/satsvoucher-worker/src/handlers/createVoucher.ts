import { Env, Voucher } from '../types';
import { jsonResponse, errorResponse, encodeLnurl, randomHex, randomVoucherId } from '../utils';

export async function createVoucher(request: Request, env: Env): Promise<Response> {
  // Authenticate the terminal
  const secret = request.headers.get('X-Worker-Secret');
  if (!secret || secret !== env.WORKER_SECRET) {
    return errorResponse('Unauthorized', 401);
  }

  let body: {
    amountBtc: number;
    amountFiat: number;
    currency: string;
    expiryDays: number;
  };

  try {
    body = await request.json();
  } catch {
    return errorResponse('Invalid JSON body', 400);
  }

  const { amountBtc, amountFiat, currency, expiryDays } = body;

  if (!amountBtc || !amountFiat || !currency || !expiryDays) {
    return errorResponse('Missing required fields: amountBtc, amountFiat, currency, expiryDays', 400);
  }

  if (amountBtc <= 0 || amountFiat <= 0) {
    return errorResponse('Amounts must be positive', 400);
  }

  const id = randomVoucherId();
  const k1 = randomHex(32);
  const now = new Date();
  const expiry = new Date(now);
  expiry.setDate(expiry.getDate() + expiryDays);

  const voucher: Voucher = {
    id,
    k1,
    amountBtc,
    amountFiat,
    currency,
    status: 'active',
    createdAt: now.toISOString(),
    expiryDate: expiry.toISOString(),
  };

  // Store in KV — TTL is expiryDays + 30 days grace period
  const ttlSeconds = (expiryDays + 30) * 24 * 60 * 60;
  await env.VOUCHERS.put(`voucher:${id}`, JSON.stringify(voucher), {
    expirationTtl: ttlSeconds,
  });

  // Build the LNURL-withdraw URL and encode it
  const workerUrl = new URL(request.url).origin;
  const lnurlwUrl = `${workerUrl}/lnurlw/${id}`;
  const lnurl = encodeLnurl(lnurlwUrl);

  return jsonResponse({
    id,
    lnurl,
    expiryDate: voucher.expiryDate,
    createdAt: voucher.createdAt,
  });
}
