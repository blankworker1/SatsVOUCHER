import { Env, Voucher } from '../types';
import { jsonResponse, errorResponse } from '../utils';

export async function voucherStatus(id: string, env: Env): Promise<Response> {
  const raw = await env.VOUCHERS.get(`voucher:${id}`);

  if (!raw) {
    return errorResponse('Voucher not found', 404);
  }

  const voucher: Voucher = JSON.parse(raw);

  // Lazily mark as expired if past expiry date
  if (voucher.status === 'active' && new Date() > new Date(voucher.expiryDate)) {
    voucher.status = 'expired';
    await env.VOUCHERS.put(`voucher:${id}`, JSON.stringify(voucher));
  }

  return jsonResponse({
    id: voucher.id,
    status: voucher.status,
    amountBtc: voucher.amountBtc,
    amountFiat: voucher.amountFiat,
    currency: voucher.currency,
    createdAt: voucher.createdAt,
    expiryDate: voucher.expiryDate,
    claimedAt: voucher.claimedAt ?? null,
  });
}
