import { Env, Voucher } from '../types';
import { jsonResponse } from '../utils';

const BLINK_API = 'https://api.blink.sv/graphql';

async function payInvoice(
  paymentRequest: string,
  walletId: string,
  apiKey: string
): Promise<void> {
  const mutation = `
    mutation LnInvoicePaymentSend($input: LnInvoicePaymentSendInput!) {
      lnInvoicePaymentSend(input: $input) {
        status
        errors { message }
      }
    }
  `;

  const response = await fetch(BLINK_API, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-KEY': apiKey,
    },
    body: JSON.stringify({
      query: mutation,
      variables: { input: { paymentRequest, walletId } },
    }),
  });

  const result: any = await response.json();

  if (result.errors?.length) {
    throw new Error(result.errors[0].message);
  }

  const { status, errors } = result.data?.lnInvoicePaymentSend ?? {};

  if (errors?.length) {
    throw new Error(errors[0].message);
  }

  if (status !== 'SUCCESS' && status !== 'PENDING') {
    throw new Error(`Payment failed with status: ${status}`);
  }
}

export async function lnurlwCallback(id: string, url: URL, env: Env): Promise<Response> {
  const k1 = url.searchParams.get('k1');
  const pr = url.searchParams.get('pr');

  if (!k1 || !pr) {
    return jsonResponse({ status: 'ERROR', reason: 'Missing k1 or pr parameters' });
  }

  const raw = await env.VOUCHERS.get(`voucher:${id}`);

  if (!raw) {
    return jsonResponse({ status: 'ERROR', reason: 'Voucher not found' });
  }

  const voucher: Voucher = JSON.parse(raw);

  if (voucher.status === 'claimed') {
    return jsonResponse({ status: 'ERROR', reason: 'Voucher already redeemed' });
  }

  if (voucher.status === 'expired' || new Date() > new Date(voucher.expiryDate)) {
    return jsonResponse({ status: 'ERROR', reason: 'Voucher has expired' });
  }

  if (voucher.k1 !== k1) {
    return jsonResponse({ status: 'ERROR', reason: 'Invalid k1' });
  }

  // Mark as claimed BEFORE paying — prevents double-spend on concurrent requests
  voucher.status = 'claimed';
  voucher.claimedAt = new Date().toISOString();
  await env.VOUCHERS.put(`voucher:${id}`, JSON.stringify(voucher));

  try {
    await payInvoice(pr, env.BLINK_WALLET_ID, env.BLINK_API_KEY);
  } catch (error: any) {
    // Payment failed — roll back claimed status so voucher can be retried
    voucher.status = 'active';
    voucher.claimedAt = undefined;
    await env.VOUCHERS.put(`voucher:${id}`, JSON.stringify(voucher));
    return jsonResponse({ status: 'ERROR', reason: error.message ?? 'Payment failed' });
  }

  return jsonResponse({ status: 'OK' });
}
