import { Env, Voucher } from '../types';
import { jsonResponse } from '../utils';

export async function lnurlwInfo(id: string, url: URL, env: Env): Promise<Response> {
  const raw = await env.VOUCHERS.get(`voucher:${id}`);

  if (!raw) {
    return jsonResponse({ status: 'ERROR', reason: 'Voucher not found' });
  }

  const voucher: Voucher = JSON.parse(raw);

  if (voucher.status === 'claimed') {
    return jsonResponse({ status: 'ERROR', reason: 'Voucher already redeemed' });
  }

  if (voucher.status === 'expired' || new Date() > new Date(voucher.expiryDate)) {
    // Mark as expired if not already
    if (voucher.status !== 'expired') {
      voucher.status = 'expired';
      await env.VOUCHERS.put(`voucher:${id}`, JSON.stringify(voucher));
    }
    return jsonResponse({ status: 'ERROR', reason: 'Voucher has expired' });
  }

  const msats = Math.round(voucher.amountBtc * 100_000_000 * 1000);

  return jsonResponse({
    tag: 'withdrawRequest',
    callback: `${url.origin}/lnurlw/callback/${id}`,
    k1: voucher.k1,
    defaultDescription: `SatsVoucher ${id} — ${voucher.currency} ${voucher.amountFiat.toFixed(2)}`,
    minWithdrawable: msats,
    maxWithdrawable: msats,
  });
}
