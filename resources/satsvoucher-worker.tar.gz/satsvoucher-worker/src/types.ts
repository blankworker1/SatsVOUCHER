export interface Env {
  VOUCHERS: KVNamespace;
  BLINK_API_KEY: string;
  BLINK_WALLET_ID: string;
  WORKER_SECRET: string;
}

export type VoucherStatus = 'active' | 'claimed' | 'expired';

export interface Voucher {
  id: string;
  k1: string;
  amountBtc: number;
  amountFiat: number;
  currency: string;
  status: VoucherStatus;
  createdAt: string;   // ISO string
  expiryDate: string;  // ISO string
  claimedAt?: string;  // ISO string, set on redemption
}
