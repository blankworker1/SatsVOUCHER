import { Env, Voucher } from './types';
import { createVoucher } from './handlers/createVoucher';
import { lnurlwInfo } from './handlers/lnurlwInfo';
import { lnurlwCallback } from './handlers/lnurlwCallback';
import { voucherStatus } from './handlers/voucherStatus';
import { errorResponse } from './utils';

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const { pathname } = url;
    const method = request.method;

    // POST /voucher — create a new voucher (terminal only, requires secret)
    if (method === 'POST' && pathname === '/voucher') {
      return createVoucher(request, env);
    }

    // GET /voucher/:id — status check for cashier
    if (method === 'GET' && pathname.startsWith('/voucher/')) {
      const id = pathname.split('/')[2];
      if (!id) return errorResponse('Missing voucher ID', 400);
      return voucherStatus(id, env);
    }

    // GET /lnurlw/:id — LNURL-withdraw info (called by customer wallet)
    if (method === 'GET' && pathname.startsWith('/lnurlw/') && !pathname.includes('/callback/')) {
      const id = pathname.split('/')[2];
      if (!id) return errorResponse('Missing voucher ID', 400);
      return lnurlwInfo(id, url, env);
    }

    // GET /lnurlw/callback/:id — redemption callback (called by customer wallet)
    if (method === 'GET' && pathname.startsWith('/lnurlw/callback/')) {
      const id = pathname.split('/')[3];
      if (!id) return errorResponse('Missing voucher ID', 400);
      return lnurlwCallback(id, url, env);
    }

    return errorResponse('Not found', 404);
  },
};

export type { Voucher };
